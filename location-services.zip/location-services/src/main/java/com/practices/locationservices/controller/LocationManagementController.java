package com.practices.locationservices.controller;

import com.practices.locationservices.LocationServicesApplication;
import com.practices.locationservices.repositories.LocationRepository;
import com.practices.locationservices.vo.LocationVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("location")
public class LocationManagementController {

    private static final Logger LOGGER = LoggerFactory.getLogger(LocationManagementController.class);
    @Autowired
    private DiscoveryClient discoveryClient;

    @Autowired
    private LocationRepository locationRepository;

    @GetMapping("/sentence")
    public @ResponseBody
    String getSentence() {
        return getWord("company-services");
    }

    @PostMapping
    public ResponseEntity<Void> saveLocation(@RequestBody LocationVO locationVO) {
        LOGGER.info("==> saveLocation={}", locationVO);
        locationRepository.save(locationVO);
        return new ResponseEntity(HttpStatus.CREATED);
    }


    public String getWord(String service) {
        List<ServiceInstance> list = discoveryClient.getInstances(service);
        if (list != null && list.size() > 0) {
            URI uri = list.get(0).getUri();
            if (uri != null) {
                return (new RestTemplate()).getForObject(uri, String.class);
            }
        }
        return null;
    }

}
