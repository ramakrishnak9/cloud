package com.practices.locationservices.repositories;

import com.practices.locationservices.vo.LocationVO;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface LocationRepository extends CrudRepository<LocationVO, Long> {

    List<LocationVO> findAll();
}
