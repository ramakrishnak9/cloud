package com.practices.locationservices.vo;

import javax.persistence.*;
import java.util.List;

@Entity
public class LocationVO {

    public Long getId() {
        return id;
    }

    public LocationVO setId(Long id) {
        this.id = id;
        return this;
    }

    public String getLocationName() {
        return locationName;
    }

    public LocationVO setLocationName(String locationName) {
        this.locationName = locationName;
        return this;
    }

    public String getAddressLine1() {
        return addressLine1;
    }

    public LocationVO setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
        return this;
    }

    public String getAddressLine2() {
        return addressLine2;
    }

    public LocationVO setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
        return this;
    }

    public String getCity() {
        return city;
    }

    public LocationVO setCity(String city) {
        this.city = city;
        return this;
    }

    public String getState() {
        return state;
    }

    public LocationVO setState(String state) {
        this.state = state;
        return this;
    }

    public int getPostalcode() {
        return postalcode;
    }

    public LocationVO setPostalcode(int postalcode) {
        this.postalcode = postalcode;
        return this;
    }

    public String getDescription() {
        return description;
    }

    public LocationVO setDescription(String description) {
        this.description = description;
        return this;
    }

    public String getTypeOfLocation() {
        return typeOfLocation;
    }

    public LocationVO setTypeOfLocation(String typeOfLocation) {
        this.typeOfLocation = typeOfLocation;
        return this;
    }

    public String getParentLocation() {
        return parentLocation;
    }

    public LocationVO setParentLocation(String parentLocation) {
        this.parentLocation = parentLocation;
        return this;
    }

    public boolean isStatus() {
        return status;
    }

    public LocationVO setStatus(boolean status) {
        this.status = status;
        return this;
    }


    @Column
    private String typeOfLocation;
    private String locationName;
    @Column
    private String parentLocation;
    @Column
    private boolean status;
    private String addressLine1;
    private String addressLine2;
    private String city;
    private String state;
    private int postalcode;
    private String description;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

}
